package edu.bu.met.cs665.main;

import edu.bu.met.cs665.deliverysystem.*;

import java.util.ArrayList;
import java.util.Scanner;

public class MainAssignment {

    public static void main(String[] args) {
        DeliveryRequest centralRequest = new DeliveryRequest();
        ArrayList<Shop> shops = new ArrayList<>();
        ArrayList<Driver> drivers = new ArrayList<>();
        shops.add(new Shop(1));
        drivers.add(new Driver(1, centralRequest));
        Scanner scanner = new Scanner(System.in);
        System.out.println("Welcome to the Delivery Program! There are currently 1 shop and 1 driver.");
        int shop_id = 2;
        int driver_id = 2;
        while (true) {
            System.out.println("Would you like to add additional shops? Please type the number of shops to add(less" +
                    " than 10, 0 to add none): ");
            try {
                int shopsToAdd = Integer.parseInt(scanner.nextLine());
                if (shopsToAdd < 0 || shopsToAdd > 10) {
                    System.out.println("Please enter a valid integer!");
                    continue;
                } else {
                    for (int i = 0; i < shopsToAdd; i += 1) {
                        Shop newShop = new Shop(shop_id);
                        for (Driver d:
                             drivers) {
                            newShop.addDriver(d);
                        }
                        shops.add(newShop);
                        shop_id += 1;
                    }
                }
            } catch (Exception e) {
                System.out.println("Please enter a valid integer!");
                continue;
            }
            System.out.println("Would you like to add additional drivers? Please type the number of shops to add(less" +
                    " than 10, 0 to add none): ");
            try {
                int driversToAdd = Integer.parseInt(scanner.nextLine());
                if (driversToAdd < 0 || driversToAdd > 10) {
                    System.out.println("Please enter a valid integer!");
                    continue;
                } else {
                    for (int i = 0; i < driversToAdd; i += 1) {
                        Driver newDriver = new Driver(driver_id, centralRequest);
                        drivers.add(newDriver);
                        for (Shop s:
                             shops) {
                            s.addDriver(newDriver);
                        }
                        driver_id += 1;
                    }
                }
            } catch (Exception e) {
                System.out.println("Please enter a valid integer!");
                continue;
            }
            System.out.println("Request Creation: Enter the store ID (0 if finished) of the request");
            Shop requester = null;
            try {
                int shopID = Integer.parseInt(scanner.nextLine());
                for (Shop s:
                     shops) {
                    if (s.getId() == shopID) {
                        requester = s;
                        break;
                    }
                }
                if (requester == null) {
                    System.out.println("No shop with that ID was found!");
                    continue;
                }
            } catch (Exception e) {
                System.out.println("Please enter a valid integer!");
                continue;
            }
            System.out.println("Please enter the order:");
            String order = scanner.nextLine();
            requester.createRequest(order);
            centralRequest.setStatus(1);
            centralRequest = new DeliveryRequest();
        }
    }
}
