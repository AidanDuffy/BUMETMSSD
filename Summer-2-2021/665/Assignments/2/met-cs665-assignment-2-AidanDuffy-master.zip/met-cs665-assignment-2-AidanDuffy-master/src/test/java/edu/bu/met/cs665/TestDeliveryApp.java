package edu.bu.met.cs665;
import edu.bu.met.cs665.deliverysystem.*;
import org.junit.Test;

import java.util.ArrayList;

import static org.junit.Assert.assertEquals;

public class TestDeliveryApp {

    @Test
    public void testObjectCreation() {
        try{
            Shop pizzeria = new Shop(1);
            DeliveryRequest request = pizzeria.createRequest("Dough");
            Driver deliveryMan = new Driver(44,request);
            assertEquals(1,1);//Passes if all objects created properly.
        }catch (Exception e) {
            assertEquals(0,1); //Fails if any exception is thrown.
        }
    }


    @Test
    public void testAssignDriver() {
        DeliveryRequest centralRequest = new DeliveryRequest();
        Shop pizzeria = new Shop(1);
        //Creating ten random Drivers
        int test_id = 44;
        Driver deliveryMan = new Driver(test_id,centralRequest);
        pizzeria.addDriver(deliveryMan);
        for (int i = 1; i <= 10; i += 1) {
            pizzeria.addDriver((new Driver(i,centralRequest)));
        }
        centralRequest = pizzeria.createRequest("Dough");
        assertEquals(centralRequest.getStatus(),0);
        centralRequest.setStatus(1);
        Driver test = centralRequest.getDriver();
        assertEquals(test,deliveryMan);
        centralRequest = new DeliveryRequest();
        String test_order = deliveryMan.getAssignedRequest().getOrder();
        assertEquals(test_order,"Dough");
    }

    @Test
    public void testnDriverBools() {
        DeliveryRequest centralRequest = new DeliveryRequest();
        Shop pizzeria = new Shop(1);
        //Creating ten random Drivers
        int test_id = 44;
        Driver deliveryMan = new Driver(test_id,centralRequest);
        pizzeria.addDriver(deliveryMan);
        for (int i = 1; i <= 10; i += 1) {
            pizzeria.addDriver((new Driver(i,centralRequest)));
        }
        centralRequest = pizzeria.createRequest("Dough");
        assertEquals(centralRequest.getStatus(),0);
        centralRequest.setStatus(1);
        Driver test = centralRequest.getDriver();
        assertEquals(test,deliveryMan);
        centralRequest = new DeliveryRequest();
        String test_order = deliveryMan.getAssignedRequest().getOrder();
        assertEquals(test_order,"Dough");
        assertEquals(false, deliveryMan.isAvailable());
        for (Driver d:
             pizzeria.getDrivers()) {
            if(d.getId() == test_id) {
                continue;
            }
            assertEquals(d.isAvailable(),true);
        }
    }
}
