package edu.bu.met.cs665.deliverysystem;

import java.util.ArrayList;

public class DeliveryRequest {

    private ArrayList<Driver> availableDrivers;
    private Driver driver;
    private String order;
    private int status = 0; // 0 for not taken, 1 for taken
    private Shop shop = null;

    public DeliveryRequest() {
        this.order = null;
        this.driver = null;
        this.availableDrivers = new ArrayList<>();
    }

    public DeliveryRequest(String order) {
        this.order = order;
        this.driver = null;
        this.availableDrivers = new ArrayList<>();
    }

    public DeliveryRequest(String order, ArrayList<Driver> drivers) {
        this.order = order;
        this.driver = null;
        this.availableDrivers = drivers;
    }

    /**
     * This returns the Driver object for this request.
     * @return the request's driver.
     */
    public Driver getDriver() {
        return driver;
    }

    /**
     * This is the order.
     * @return the request's order.
     */
    public String getOrder() {
        return order;
    }


    public Shop getShop() {
        return shop;
    }

    /**
     * This gets whether or not a driver is on this request.
     * @return the request's status.
     */
    public int getStatus() {
        return status;
    }

    /**
     * Based on the status of the request (0 is not in use, 1 is being assigned a driver),
     * the program will either remove the driver or set the driver and update whether or not
     * drivers are searching for this job.
     */
    public void notifyObservers() {
        if (getStatus() == 1)  {
            Driver assigned = null;
            for (Driver d :
                    this.availableDrivers) {
                Driver update = d.update();
                if (assigned == null && update != null) {
                    assigned = update;
                    if (!assigned.isAvailable()) {
                        assigned = null;
                    }
                }
            }
            setDriver(assigned);
        } else if (getStatus() == 0){
            setDriver(null);
            for (Driver d :
                    this.availableDrivers) {
                d.update();
            }
        }

    }

    /**
     * Adds a driver to the list of all drivers.
     * @param driver being added.
     */
    public void registerDriver(Driver driver) {
        this.availableDrivers.add(driver);
    }

    /**
     * Remove a driver from the list of all drivers.
     * @param driver
     */
    public void removeDriver(Driver driver) {
        this.availableDrivers.remove(driver);
    }

    /**
     * This sets the driver.
     * @param driver is the request's driver.
     */
    public void setDriver(Driver driver) {
        this.driver = driver;
        if (driver != null) {
            this.driver.setAssignedRequest(this);
        }
    }

    /**
     * This sets the request order.
     * @param order
     */
    public void setOrder(String order) {
        this.order = order;
    }

    public void setShop(Shop shop) {
        this.shop = shop;
    }

    /**
     * This sets the request status.
     * @param status
     */
    public void setStatus(int status) {
        this.status = status;
        notifyObservers();
    }
}
