package edu.bu.met.cs665.deliverysystem;

public class Driver {

    private int id;
    private boolean available;
    private boolean searching;
    DeliveryRequest subject;
    DeliveryRequest assignedRequest;

    public Driver(int id, DeliveryRequest request){
        this.id = id;
        this.available = true;
        this.searching = false;
        this.subject = request;
        this.assignedRequest = null;
    }

    /**
     * Gets the driver's assigned request, if any.
     * @return
     */
    public DeliveryRequest getAssignedRequest() {
        return assignedRequest;
    }

    /**
     * Gets the driver ID.
     * @return driver's ID.
     */
    public int getId() {
        return id;
    }

    /**
     * Checks if the driver is available.
     * @return
     */
    public boolean isAvailable() {
        return available;
    }

    /**
     * Returns whether or not a driver is being considered for a job.
     * @return
     */
    public boolean isSearching() {
        return searching;
    }

    /**
     * Sets a driver's availability.
     * @param available
     */
    public void setAvailable(boolean available) {
        this.available = available;
    }

    /**
     * Assigned a delivery request to this driver.
     * @param assignedRequest
     */
    public void setAssignedRequest(DeliveryRequest assignedRequest) {
        this.assignedRequest = new DeliveryRequest(assignedRequest.getOrder());
        this.assignedRequest.setShop(assignedRequest.getShop());
        setAvailable(false);
    }

    /**
     * Sets a driver's id.
     * @param id
     */
    public void setId(int id) {
        this.id = id;
    }

    public void setSearching(boolean searching) {
        this.searching = searching;
    }

    public Driver update() {
        if (isAvailable()) {
            this.setSearching(!isSearching());
            return this;
        } else {
            this.setSearching(false);
            return null;
        }
    }
}
