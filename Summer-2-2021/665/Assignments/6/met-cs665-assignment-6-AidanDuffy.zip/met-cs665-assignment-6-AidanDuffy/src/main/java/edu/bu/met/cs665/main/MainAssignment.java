package edu.bu.met.cs665.main;

import edu.bu.met.cs665.deliverysystem.DeliveryRequest;
import edu.bu.met.cs665.deliverysystem.Driver;
import edu.bu.met.cs665.deliverysystem.Shop;

import java.util.ArrayList;
import java.util.Scanner;

public class MainAssignment {

  public static void main(String[] args) {
	DeliveryRequest centralRequest = new DeliveryRequest();
	ArrayList<Shop> shops = new ArrayList<>();
	ArrayList<Driver> drivers = new ArrayList<>();
	shops.add(new Shop(1));
	drivers.add(new Driver(1, centralRequest));
	Scanner scanner = new Scanner(System.in);
	System.out.println("Welcome to the Delivery Program! There are currently 1 shop and 1 driver.");
	int shop_id = 2;
	int driver_id = 2;
	while (true) {
	  shop_id = getShopId(shops, drivers, scanner, shop_id);
	  if (shop_id == -1) {
		continue;
	  }
	  driver_id = getDriverId(centralRequest, shops, drivers, scanner, driver_id);
	  if (driver_id == -1) {
		continue;
	  }
	  Shop requester = getShop(shops, scanner);
	  if (requester.getId() == 0) {
		break;
	  }
	  System.out.println("Please enter the order:");
	  String order = scanner.nextLine();
	  requester.createRequest(order);
	  centralRequest.setStatus(1);
	  centralRequest = new DeliveryRequest();
	}
  }

  private static Shop getShop(ArrayList<Shop> shops, Scanner scanner) {
	System.out.println("Request Creation: Enter the store ID (0 if finished) of the request");
	Shop requester = null;
	try {
	  int shopID = Integer.parseInt(scanner.nextLine());
	  if (shopID == 0) {
		return new Shop(0);
	  }
	  for (Shop s :
		  shops) {
		if (s.getId() == shopID) {
		  requester = s;
		  break;
		}
	  }
	  if (requester == null) {
		System.out.println("No shop with that ID was found!");
		return null;
	  }
	} catch (Exception e) {
	  System.out.println("Please enter a valid integer!");
	  return null;
	}
	return requester;
  }

  private static int getDriverId(DeliveryRequest centralRequest, ArrayList<Shop> shops, ArrayList<Driver> drivers, Scanner scanner, int driver_id) {
	System.out.println("Would you like to add additional drivers? Please type the number of shops to add(less" +
		" than 10, 0 to add none): ");
	try {
	  int driversToAdd = Integer.parseInt(scanner.nextLine());
	  if (driversToAdd < 0 || driversToAdd > 10) {
		System.out.println("Please enter a valid integer!");
		return -1;
	  } else {
		for (int i = 0; i < driversToAdd; i += 1) {
		  Driver newDriver = new Driver(driver_id, centralRequest);
		  drivers.add(newDriver);
		  for (Shop s :
			  shops) {
			s.addDriver(newDriver);
		  }
		  driver_id += 1;
		}
	  }
	} catch (Exception e) {
	  System.out.println("Please enter a valid integer!");
	  return -1;
	}
	return driver_id;
  }

  private static int getShopId(ArrayList<Shop> shops, ArrayList<Driver> drivers, Scanner scanner, int shop_id) {
	System.out.println("Would you like to add additional shops? Please type the number of shops to add(less" +
		" than 10, 0 to add none): ");
	try {
	  int shopsToAdd = Integer.parseInt(scanner.nextLine());
	  if (shopsToAdd < 0 || shopsToAdd > 10) {
		System.out.println("Please enter a valid integer!");
		return -1;
	  } else {
		for (int i = 0; i < shopsToAdd; i += 1) {
		  Shop newShop = new Shop(shop_id);
		  for (Driver d :
			  drivers) {
			newShop.addDriver(d);
		  }
		  shops.add(newShop);
		  shop_id += 1;
		}
	  }
	} catch (Exception e) {
	  System.out.println("Please enter a valid integer!");
	  return -1;
	}
	return shop_id;
  }
}
