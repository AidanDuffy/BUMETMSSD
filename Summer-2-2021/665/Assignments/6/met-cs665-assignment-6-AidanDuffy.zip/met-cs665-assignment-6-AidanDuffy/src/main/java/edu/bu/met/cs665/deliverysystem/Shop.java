package edu.bu.met.cs665.deliverysystem;

import java.util.ArrayList;

public class Shop {

  private final ArrayList<Driver> allDrivers;
  private int id;
  private DeliveryRequest request;

  public Shop(int id) {
	this.id = id;
	this.request = null;
	this.allDrivers = new ArrayList<>();
  }

  public DeliveryRequest createRequest(String order) {
	DeliveryRequest req = new DeliveryRequest(order, allDrivers);
	req.setShop(this);
	this.request = req;
	return request;
  }

  /**
   * Adds a driver to the list of all drivers.
   *
   * @param driver being added.
   */
  public void addDriver(Driver driver) {
	this.allDrivers.add(driver);
	if (this.request != null) {
	  this.request.registerDriver(driver);
	}
  }

  public ArrayList<Driver> getDrivers() {
	return this.allDrivers;
  }

  /**
   * This returns the ID of the store.
   *
   * @return the store's ID.
   */
  public int getId() {
	return id;
  }

  /**
   * Sets a new id for the shop.
   *
   * @param id is the shop's new id.
   */
  public void setId(int id) {
	this.id = id;
  }

  /**
   * This gets the shop's current delivery request.
   *
   * @return the current delivery request.
   */
  public DeliveryRequest getRequest() {
	return request;
  }

  /**
   * Remove a driver from the list of all drivers.
   *
   * @param driver
   */
  public void removeDriver(Driver driver) {
	this.allDrivers.remove(driver);
	if (this.request != null) {
	  this.request.removeDriver(driver);
	}
  }


}
