# Project Template

This is a Java Maven Project Template


# How to compile the project

We use Apache Maven to compile and run this project. 

You need to install Apache Maven (https://maven.apache.org/)  on your system. 

Type on the command line: 

```bash
mvn clean compile
```

# How to create a binary runnable package 


```bash
mvn clean compile assembly:single
```


# How to run

```bash
mvn -q clean compile exec:java -Dexec.executable="edu.bu.met.cs665.machine.MainAssignment" -Dlog4j.configuration="file:log4j.properties"
```

We recommand the above command for running the Main Java executable. 




# Run all the unit test classes.


```bash
mvn clean compile test checkstyle:check  spotbugs:check
```

# Using Spotbugs to find bugs in your project 

To see bug detail using the Findbugs GUI, use the following command "mvn findbugs:gui"

Or you can create a XML report by using  


```bash
mvn spotbugs:gui 
```

or 


```bash
mvn spotbugs:spotbugs
```


```bash
mvn spotbugs:check 
```

check goal runs analysis like spotbugs goal, and make the build failed if it found any bugs. 


For more info see 
https://spotbugs.readthedocs.io/en/latest/maven.html


SpotBugs https://spotbugs.github.io/ is the spiritual successor of FindBugs.


# Run Checkstyle 

CheckStyle code styling configuration files are in config/ directory. Maven checkstyle plugin is set to use google code style. 
You can change it to other styles like sun checkstyle. 

To analyze this example using CheckStyle run 

```bash
mvn checkstyle:check
```

This will generate a report in XML format


```bash
target/checkstyle-checker.xml
target/checkstyle-result.xml
```

and the following command will generate a report in HTML format that you can open it using a Web browser. 

```bash
mvn checkstyle:checkstyle
```

```bash
target/site/checkstyle.html
```


# Description

### Flexibility
In terms of flexibility, it is my goal to ensure that this program is as flexible as possible. Therefore, there will be
an abstract class for drinks as well as "condiments" so that it is easy to add or remove new types of drinks, like soda or juice
as well as ice or artificial sweeteners. These new additions would simply be added through inheritance that are subclasses
of the drink abstract class.

###Simplicity and Understandability
I wanted to ensure that the code was modular, utilized encapsulation, and properly marked, well named, and commented so
that it was not cluttered, easy for developers to read, and simple enough to understand. The abstract class and all the
inheritance should separate everything in such a way that it will be easy to navigate and understand everythings purpose.

###Duplication Avoidance
I wanted to use a condiments and drink interface so that there was limited duplication and that any unique aspects for 
coffee vs tea or milk vs sugar would simply be limited to their individual inheritances of their classes.

###Design Patterns
I utilized inheritance while using a drink abstract class, and the machine itself will be "composed" of all the possible options
of drinks and aggregated of all the "condiments". This is composition because without any drink options, the machine has
no function, but it can function without those condiments. As I mentioned before, I used modularization and encapsulation
so that it was easily readable and understandable.

###General Overview
I will have several packages: beverage(for the drink and condiment abstract class and all implementations) and machine (for 
the DrinkMachine class). The abstract classes and implementations will be implemented as described above with associated prices,
max quantities for condiments, etc. The machine will run the entire program such as asking the user for their drink
preference, drink type, and condiment choices then dispense the drink. All of these will have associated JUnit tests.

# Running the Program

Simply run on the MainAssignment.java  in the machine package, file NOT the Main.java file.