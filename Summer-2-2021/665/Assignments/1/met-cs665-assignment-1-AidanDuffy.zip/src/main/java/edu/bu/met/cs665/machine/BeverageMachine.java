package edu.bu.met.cs665.machine;

import edu.bu.met.cs665.beverage.Coffee;
import edu.bu.met.cs665.beverage.Drink;
import edu.bu.met.cs665.beverage.Tea;

import java.util.ArrayList;
import java.util.Scanner;

public class BeverageMachine {

    public double costOfOrder;
    public double customerBudget;
    public ArrayList<Drink> order;
    public static final String[] condimentOptions = new String[]{"Milk", "Sugar"};
    public static final String[] drinkOptions = new String[]{"Coffee", "Tea"};


    public BeverageMachine() {
        this.costOfOrder = 0.0;
        this.order = new ArrayList<>();
        this.customerBudget = 100.0;
    }

    public BeverageMachine(double customerBudget) {
        this.costOfOrder = 0.0;
        this.order = new ArrayList<>();
        this.customerBudget = customerBudget;
    }

    /**
     * This adds a drink to the list of drinks and the cost to the order cost.
     * @param drink is the Drink object.
     */
    public void addDrinkToOrder(Drink drink) {
        this.order.add(drink);
        this.costOfOrder += drink.getCurrentCost();
    }

    /**
     * This does the leg work of creating a new Drink object.
     */
    public void createNewDrink() {
        Drink drink = null;
        Scanner scanner = new Scanner(System.in);
        while(true) {
            System.out.println("Please type which drink type you would like to add by typing the name EXACTLY:");
            for (String dr : this.getDrinkOptions()) {
                System.out.println(dr);
            }
            System.out.println();
            String drinkType = scanner.nextLine();
            if (drinkType.equals("Coffee")) {
                drink = (createNewCoffee());
                break;
            } else if (drinkType.equals("Tea")) {
                drink = (createNewTea());
                break;
            } else {
                System.out.println("Invalid Drink!");
            }
        }
        System.out.println("Would you like to add condiments? (Type \"yes\" exactly, otherwise this will exit!)");
        String addCondiments = scanner.nextLine();
        while (addCondiments.equals("yes")) {
            String cond = "";
            int amount = 0;
            System.out.println("Condiment Options (Type the one you want to add exactly!): ");
            for(String condiment: this.getCondimentOptions()) {
                System.out.println(condiment);
            }
            System.out.println();
            cond = scanner.nextLine();
            boolean valid = false;
            for(String condiment: this.getCondimentOptions()) {
                if (cond.equals(condiment)) {
                    valid = true;
                }
            }
            if (!valid) {
                System.out.println("Invalid selection, try again!");
            } else {
                System.out.println("Please input an integer for the amount of this condiment you want to add (less than 3!)");
                try {
                    amount = Integer.parseInt(scanner.nextLine());
                } catch (Exception e) {
                    System.out.println("Invalid integer! Resetting...");
                    continue;
                }
                if (amount > 3 || amount < 1) {
                    System.out.println("Invalid integer! Resetting...");
                    continue;
                } else {
                    drink.addCondiment(cond, amount);
                    System.out.println("Would you like to add more condiments? (Type \"yes\" exactly, if so!)");
                    addCondiments = scanner.nextLine();
                }
            }
        }
        this.addDrinkToOrder(drink);
        System.out.println("Drink added!");
    }

    /**
     * Creates the new coffee object for the createNewDrink()
     * @return the new coffee object
     */
    public Coffee createNewCoffee() {
        Coffee coffee = new Coffee();
        //This gets the type of coffee
        while(true) {
            Scanner scanner = new Scanner(System.in);
            System.out.println("Please type which coffee type you would like to add by typing the name EXACTLY:");
            for (String dr : coffee.coffeeOptions) {
                System.out.println(dr);
            }
            System.out.println();
            String drinkType = scanner.nextLine();
            boolean correct = false;
            for (String dr : coffee.coffeeOptions) {
                if (drinkType.equals(dr)) {
                    correct = true;
                }
            }
            if (correct) {
                coffee.setCoffeeType(drinkType);
                break;
            } else {
                System.out.println("Error! Bad coffee type input.");
            }
        }
        return coffee;
    }

    /**
     * Creates the new tea object for the createNewDrink()
     * @return the new tea object
     */
    public Tea createNewTea() {
        Tea tea = new Tea();
        while(true) {
            Scanner scanner = new Scanner(System.in);
            System.out.println("Please type which coffee type you would like to add by typing the name EXACTLY:");
            for (String dr : tea.TeaOptions) {
                System.out.println(dr);
            }
            System.out.println();
            String drinkType = scanner.nextLine();
            boolean correct = false;
            for (String dr : tea.TeaOptions) {
                if (drinkType.equals(dr)) {
                    correct = true;
                }
            }
            if (correct) {
                tea.setTeaType(drinkType);
                break;
            } else {
                System.out.println("Error! Bad coffee type input.");
            }
        }
        return tea;
    }

    public static String[] getCondimentOptions() {
        return condimentOptions;
    }

    /**
     * This returns the order cost.
     * @return the cost of the order.
     */
    public double getCostOfOrder() {
        return costOfOrder;
    }

    public static String[] getDrinkOptions() {
        return drinkOptions;
    }

    /**
     * This returns a String of all of the drinks and their condiments.
     * @return a string of all of the drinks, their condiments.
     */
    public String getOrderDetails() {
        String details = "";
        for(Drink d: this.order) {
            if (d instanceof Tea) {
                Tea t = (Tea) d;
                details += t.getTeaType() + " Tea";
            } else {
                Coffee c = (Coffee) d;
                details += c.getCoffeeType() + " Coffee";
            }
            details += "\n" + d.getCondiments();
        }
        return details;
    }

    /**
     * This ensures the customer can afford their order.
     * @return true if the cost is less than a user's budget.
     */
    public boolean verifyAffordability() {
        return this.costOfOrder <= this.customerBudget;
    }
}
