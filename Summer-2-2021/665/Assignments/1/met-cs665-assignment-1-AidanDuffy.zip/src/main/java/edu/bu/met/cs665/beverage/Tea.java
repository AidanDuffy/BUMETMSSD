package edu.bu.met.cs665.beverage;

public class Tea extends Drink {

    public static final String[] TeaOptions = new String[]{"Black", "Yellow", "Green"};
    public String teaType;

    public Tea() {
        super();
        this.teaType = "";
    }

    public Tea(String type) {
        super();
        for (String option: TeaOptions) {
            if (type.equals(option)) {
                this.setTeaType(type);
            }
        }
        if (this.teaType == null) {
            //insert error
        }
    }

    /**
     * This gets the caller the type of tea.
     * @return the tea type.
     */
    public String getTeaType() {
        return this.teaType;
    }

    /**
     * This changes the tea type
     * @param teaType is the new type of tea.
     */
    public void setTeaType(String teaType) {
        this.teaType = teaType;
    }
}
