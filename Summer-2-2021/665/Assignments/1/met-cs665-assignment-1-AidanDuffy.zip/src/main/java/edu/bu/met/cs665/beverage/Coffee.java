package edu.bu.met.cs665.beverage;

public class Coffee extends Drink{

    public static final String[] coffeeOptions = new String[]{"Regular", "Espresso", "Americano", "Latte Macchiato"};
    public String coffeeType;

    public Coffee() {
        super();
        this.coffeeType = "";
    }

    public Coffee(String type) {
        super();
        for (String option: coffeeOptions) {
            if (type.equals(option)) {
                this.setCoffeeType(type);
            }
        }
        if (this.coffeeType == null) {
            //insert error
        }
    }

    /**
     * This gets the caller the type of coffee.
     * @return the coffee type.
     */
    public String getCoffeeType() {
        return coffeeType;
    }

    /**
     * This changes the coffee type
     * @param coffeeType is the new type of coffee.
     */
    public void setCoffeeType(String coffeeType) {
        this.coffeeType = coffeeType;
    }
}
