package edu.bu.met.cs665.machine;

import java.util.Scanner;

public class MainAssignment {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Welcome to the Beverage Machine! Please enter your order budget: ");

        double budget = 0.0;
        while (true) {
            try {
                budget = Double.parseDouble(scanner.nextLine());
                break;
            } catch (Exception e) {
                System.out.println("Error! Please enter a valid integer/double!");
            }
        }
        BeverageMachine bm = new BeverageMachine(budget);
        String moreDrinks = "yes";
        while (moreDrinks.equals("yes")) {
            bm.createNewDrink();
            System.out.println("Drink added. Do you need to add more? (Type \"yes\")");
            moreDrinks = scanner.nextLine();
        }
        System.out.println("Finished adding drinks! Here are your order details:");
        System.out.println(bm.getOrderDetails());
    }
}
