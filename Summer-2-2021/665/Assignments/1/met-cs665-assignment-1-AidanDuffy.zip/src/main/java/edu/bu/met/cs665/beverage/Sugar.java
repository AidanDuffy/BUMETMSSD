package edu.bu.met.cs665.beverage;

public class Sugar extends Condiment{

    //Does the consumer need artificial sweetners?
    private boolean articificalSweetner = false;
    public String typeOfSugar = "Sugar";
    public static String[] sugarOptions = new String[]{"Sugar","Sweet n Low", "Stevia"};

    public Sugar() {
        super();
        this.setName("Sugar");
    }

    public Sugar(int count) {
        super();
        this.setName("Sugar");
        boolean added = this.addCondiment(count);
        if(!added) {
            throw new IllegalStateException();
        }
    }

    /**
     * This gives users to all of the sugar options in a string, seperated by line.
     * @return a string of all sugar.
     */
    public String getSugarOptions() {
        String sugars = "";
        for(String sugar: sugarOptions) {
            sugars +=  sugar + "\n";
        }
        return sugars;
    }

    /**
     * This changes the need for a non-sugar sweetner.
     * @param articificalSweetner is true if the consumer opts to not have regular sugar.
     */
    public void setArticifical(boolean articificalSweetner) {
        this.articificalSweetner = articificalSweetner;
    }

    /**
     * This changes the type of sugar.
     * @param type is the new sugar type.
     */
    public void setSugarType(String type) {
        boolean changed = false;
        for(String sugars: sugarOptions) {
            if (type.equals(sugars)) {
                this.typeOfSugar = type;
                changed = true;
            }
        }
        if (!changed) {
            //Error
        }
    }
}
