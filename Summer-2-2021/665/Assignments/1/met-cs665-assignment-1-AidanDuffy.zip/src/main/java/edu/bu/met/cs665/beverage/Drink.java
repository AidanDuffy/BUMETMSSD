package edu.bu.met.cs665.beverage;

import java.util.ArrayList;

public abstract class Drink {

    private ArrayList<Condiment> condiments;
    public static final String[] condimentOptions = new String[]{"Milk", "Sugar"};
    private double currentCost = 0.0;
    public static final String[] drinkOptions = new String[]{"Coffee", "Tea"};
    private boolean hotDrink;

    public Drink() {
        this.condiments = new ArrayList<>();
    }

    /**
     * This adds a condiment to a drink.
     * @param condimentName is the name of the condiment type (milk or sugar only for now).
     * @param count is the number of this condiment that will be added.
     * @return true or false if the condiment was added.
     */
    public boolean addCondiment(String condimentName, int count) {

        boolean containsCondiment = false;
        boolean added = false;
        for (Condiment cond: this.condiments) {
            if (condimentName.equals(cond.getCondimentName())) {
                containsCondiment = true;
                if(cond.addCondiment(count)) {
                    added = true;
                    break;
                }
            }
        }
        if (!containsCondiment) {
            for (String cond: this.condimentOptions) {
                if(condimentName.equals(cond)) {
                    added = true;
                    Condiment newCondiment;
                    if (condimentName.equals("Milk")) {
                        newCondiment = new Milk(count);
                    } else if (condimentName.equals("Sugar")) {
                        newCondiment = new Sugar(count);
                    } else {
                        //Add error message.
                        added = false;
                        break;
                    }
                    this.condiments.add(newCondiment);
                }
            }
        }
        return added;
    }

    /**
     * This adds new changes in cost to the current cost.
     * @param priceIncrease is the increase in cost.
     */
    private void addToCost(double priceIncrease) {
        this.currentCost += priceIncrease;
    }

    /**
     * This returns the condiment object by searching its name. If it is not there, return null.
     * @param condiment is the name of the condiment.
     * @return the actual condiment object.
     */
    public Condiment getCondimentByName(String condiment) {
        Condiment c = null;
        for(Condiment cond: this.condiments) {
            if (cond.getCondimentName().equals(condiment)) {
                c = cond;
                break;
            }
        }
        return c;
    }

    /**
     * This returns the condiments currently in the beverage.
     * @return a string composed of all the condiments and their amounts, seperated by lines.
     */
    public String getCondiments() {
        String condimentNames = "";
        for(Condiment cond: this.condiments) {
            condimentNames +=  cond.name + ": " + Integer.toString(cond.curAmount) + "\n";
        }
        return condimentNames;
    }

    /**
     * Returns the number of a specific condiment in a drink, else -1.
     * @param condiment the condiment we are looking for.
     * @return the number of units of this condiment in the drink.
     */
    public int getCondimentCount(String condiment) {
        int count = -1;
        for(Condiment cond: this.condiments) {
            if (cond.getCondimentName().equals(condiment)) {
                count = cond.getCurAmount();
                break;
            }
        }
        return count;
    }

    /**
     * This gives users to all of the condiment options in a string, seperated by line.
     * @return a string of all condiments.
     */
    public String getCondimentOptions() {
        String condimentNames = "";
        for(String cond: this.condimentOptions) {
            condimentNames +=  cond + "\n";
        }
        return condimentNames;
    }

    /**
     * This returns the current cost of this drink.
     * @return the current cost of the drink.
     */
    public double getCurrentCost() {
        return currentCost;
    }

    /**
     * This gives users to all of the drink options in a string, seperated by line.
     * @return a string of all drinks.
     */
    public String getDrinkOptions() {
        String drinks = "";
        for(String drink: this.drinkOptions) {
            drinks +=  drink + "\n";
        }
        return drinks;
    }

    /**
     * This checks if the drink is hot or cold(iced).
     * @param hot is the true/false value, set to true if the drink is hot/not iced.
     */
    private void setHotOrCold(boolean hot) {
        this.hotDrink = hot;
    }
}
