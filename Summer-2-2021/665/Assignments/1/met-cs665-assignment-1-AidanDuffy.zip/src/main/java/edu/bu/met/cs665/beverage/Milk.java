package edu.bu.met.cs665.beverage;

public class Milk extends Condiment{

    private boolean lactoseIntolerantCustomer = false;
    public String[] milkOptions = new String[]{"Whole", "Almond","Oat", "2%", "Skim"};
    protected String typeOfMilk = "Whole";
    private boolean veganCustomer = false;

    public Milk() {
        super();
        this.setName("Milk");
    }

    public Milk(int count) {
        super();
        this.setName("Milk");
        boolean added = this.addCondiment(count);
        if(!added) {
            throw new IllegalStateException();
        }
    }

    /**
     * This gives users to all of the milk options in a string, seperated by line.
     * @return a string of all milk.
     */
    public String getMilkOptions() {
        String milks = "";
        for(String milk: milkOptions) {
            milks +=  milk + "\n";
        }
        return milks;
    }

    /**
     * Checks if user is lactose intolerant and/or vegan.
     * @return true if they opt not to have or can not have milk.
     */
    protected boolean getLactoseIntoleranceOrVegan() {
        return this.lactoseIntolerantCustomer || this.veganCustomer;
    }

    /**
     * This changes the type of milk.
     * @param type is the new milk type.
     */
    protected void setMilkType(String type) {
        boolean changed = false;
        for(String milk: milkOptions) {
            if (type.equals(milk)) {
                this.typeOfMilk = type;
                changed = true;
            }
        }
        if (!changed) {
            //Error
        }
    }

    /**
     * This sets a user's vegan and lactose intolerance statuses.
     * @param vegan is whether or not they are vegan.
     * @param intolerant is true if they are lactose intolerant.
     */
    protected void setVeganLactose(boolean vegan, boolean intolerant) {
        this.veganCustomer = vegan;
        this.lactoseIntolerantCustomer = intolerant;
    }
}
