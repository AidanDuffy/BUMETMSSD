package edu.bu.met.cs665.beverage;

public abstract class Condiment {

    protected int curAmount;
    protected int maxAmount = 3;
    protected String name;

    public Condiment(){
        this.name = "";
        this.curAmount = 0;
    }

    public boolean addCondiment(int amount) {
        boolean added = false;
        if (!checkIfMaxAmount()) {
            if (this.getCurAmount() + amount <= this.maxAmount) {
                this.curAmount += amount;
                added = true;
            }
        }
        return added;
    }

    protected boolean checkIfMaxAmount() {
        return curAmount == maxAmount;
    }

    protected String getCondimentName() {
        return this.name;
    }

    protected int getCurAmount() {
        return this.curAmount;
    }

    protected void setName(String newName) {
        this.name = newName;
    }
}
