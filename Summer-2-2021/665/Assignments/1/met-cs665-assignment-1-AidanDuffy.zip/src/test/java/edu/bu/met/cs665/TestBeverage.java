package edu.bu.met.cs665;
import edu.bu.met.cs665.beverage.*;
import org.junit.Assert;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class TestBeverage {

    @Test
    public void testMaxCondimentAndCheckCounts() {
        Sugar sugar;
        try {
            sugar = new Sugar(4);
            Assert.assertEquals(0,1);
        } catch (IllegalStateException e) {
            Assert.assertEquals(1,1);
        }
        sugar = new Sugar(3);
        boolean added;
        added = sugar.addCondiment(1);
        assertEquals(false, added);
        Coffee coffee = new Coffee("Espresso");
        try {
            coffee.addCondiment("Sugar", 5);
            assertEquals(0,1);
        } catch (IllegalStateException e) {
            assertEquals(0,0);
        }
        int count = 2;
        coffee.addCondiment("Sugar",count);
        int sugars = coffee.getCondimentCount("Sugar");
        assertEquals(sugars,count);
        sugars = coffee.getCondimentCount("Milk");
        assertEquals(sugars,-1);
    }


    @Test
    public void testCondimentTypes() {
        Sugar c1 = new Sugar(1);
        c1.setSugarType("Stevia");
        Sugar c2;
        Coffee c = new Coffee("Americano");
        c.addCondiment("Sugar",1);
        c2 = (Sugar) c.getCondimentByName("Sugar");
        c2.setSugarType("Stevia");
        assertEquals(c1.typeOfSugar, c2.typeOfSugar);
    }

    @Test
    public void testAddedCondiments() {
        Coffee c = new Coffee("Americano");
        c.addCondiment("Sugar",1);
        c.addCondiment("Milk",3);
        String test = "Sugar: 1\nMilk: 3\n";
        assertEquals(test, c.getCondiments());
    }
}
