package edu.bu.met.cs665;


public class Main {


  /**
   * A main method to run examples.
   *
   * @param args not used
   */
  public static void main(String[] args) {
    EmailGenerationSystem system = EmailGenerationSystem.getSystemSingleton();
    system.createCompany("Apple");
    system.createCompany("Tesla");
    system.runSystem();
  }

}
