package edu.bu.met.cs665.customerfactory;

public class Vip extends Customer {
  @Override
  String getBody() {
    return "Here is the VIP-specific information.";
  }

  @Override
  String getFooter() {
    return "Keep being a VIP!";
  }

  @Override
  String getHeader() {
    return "Hello VIPs!";
  }
}
