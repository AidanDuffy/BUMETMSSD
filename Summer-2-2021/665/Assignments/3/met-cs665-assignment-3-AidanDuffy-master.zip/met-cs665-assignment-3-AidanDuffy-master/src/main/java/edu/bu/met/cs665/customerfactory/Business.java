package edu.bu.met.cs665.customerfactory;

import edu.bu.met.cs665.Email;

public class Business extends Customer {

  private static final String ENCRYPTION_PASSWORD = "template";

  @Override
  String getBody() {
    return "Here is the Business-specific information.";
  }

  @Override
  public Email getEmail() {
    Email email = super.getEmail();
    return email.encrypt(ENCRYPTION_PASSWORD);
  }

  @Override
  String getFooter() {
    return "Please contact the Business specific customer service line with any questions.";
  }

  @Override
  String getHeader() {
    return "Attention: Business customers";
  }
}
