package edu.bu.met.cs665.customerfactory;

public class Returning extends Customer {
  @Override
  String getBody() {
    return "Here is the Returning-specific information.";
  }

  @Override
  String getFooter() {
    return "We hope we will be seeing you again!";
  }

  @Override
  String getHeader() {
    return "Welcome back!";
  }
}
