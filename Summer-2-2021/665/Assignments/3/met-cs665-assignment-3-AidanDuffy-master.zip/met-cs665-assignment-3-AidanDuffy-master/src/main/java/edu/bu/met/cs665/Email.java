package edu.bu.met.cs665;

public class Email {

  private final String body;
  private final String footer;
  private final String header;
  private boolean encrypted = false;
  private String password;


  /**
   * Standard Email object constructor.
   * @param body of the email.
   * @param footer of the email.
   * @param header of the email.
   */
  public Email(String body, String footer, String header) {
    this.body = body;
    this.footer = footer;
    this.header = header;
  }

  /**
   * This returns a decrypted version of an encrypted email.
   *
   * @param pass is the password for the encryption
   * @return the decrypted email
   */
  public Email decrypt(String pass) {
    if (this.encrypted && pass.equals(this.password)) {
      this.encrypted = false;
    }
    return this;
  }

  /**
   * This returns an encrypted version of a given email.
   *
   * @param pass is the password for the encryption
   * @return the encrypted email.
   */
  public Email encrypt(String pass) {
    if (!this.encrypted) {
      this.encrypted = true;
      this.password = pass;
    }
    return this;
  }

  @Override
  public String toString() {
    if (!encrypted) {
      return header + "\n" + body + "\n" + footer;
    } else {
      return "Email encrypted.";
    }

  }
}
