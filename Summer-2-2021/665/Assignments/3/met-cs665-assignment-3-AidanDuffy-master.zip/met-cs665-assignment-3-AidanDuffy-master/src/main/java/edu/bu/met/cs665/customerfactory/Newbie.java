package edu.bu.met.cs665.customerfactory;

public class Newbie extends Customer {
  @Override
  String getBody() {
    return "Here is the Newbie-specific information.";
  }

  @Override
  String getFooter() {
    return "Again, welcome to our company!";
  }

  @Override
  String getHeader() {
    return "Welcome to our company!";
  }
}
