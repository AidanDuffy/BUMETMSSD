package edu.bu.met.cs665.customerfactory;

import edu.bu.met.cs665.Email;

public abstract class Customer {

  private static final String STANDARD_BODY = "The text for all customers...";

  /**
   * Dependent on subclass, this will return that Customer type's email body.
   * @return this Customer's body template.
   */
  abstract String getBody();

  /**
   * Dependent on subclass, this will return that Customer type's email footer.
   * @return this Customer's footer template.
   */
  abstract String getFooter();

  /**
   * Dependent on subclass, this will return that Customer type's email header.
   * @return this Customer's header template.
   */
  abstract String getHeader();

  /**
   * This creates and returns a new Email object with the given customer's
   * header, body, and footer, including the body that is sent to all customers.
   * @return the email object.
   */
  public Email getEmail() {
    return new Email(getBody() + "\n" + STANDARD_BODY, getFooter(), getHeader());
  }
}
