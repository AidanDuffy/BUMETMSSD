package edu.bu.met.cs665;

import java.util.ArrayList;
import java.util.Scanner;

public class EmailGenerationSystem {

  private static final String[] TYPES = {"Business", "Frequent", "Newbie", "Returning", "VIP"};
  private static final EmailGenerationSystem singleton = new EmailGenerationSystem();
  private final ArrayList<Company> companies;

  private EmailGenerationSystem() {
    this.companies = new ArrayList<>();
  }

  public static EmailGenerationSystem getSystemSingleton() {
    return singleton;
  }

  /**
   * Adds a company to the system's logged systems.
   *
   * @param name of the company.
   */
  public void createCompany(String name) {
    Company company = new Company(name);
    companies.add(company);
  }

  private Company getCompany() {
    Scanner scanner = new Scanner(System.in, "UTF-8");
    System.out.println("Companies on file: ");
    for (int i = 1; i <= companies.size(); i += 1) {
      System.out.println(i + ". " + companies.get(i - 1).getName());
    }
    int index;
    while (true) {
      System.out.println("Enter in the integer with your corresponding company or zero to exit: ");
      try {
        index = Integer.parseInt(scanner.nextLine());
        if (index < 0 || index > companies.size() + 1) {
          System.out.println("Invalid index! Try again...");
          continue;
        } else if (index == 0) {
          return null;
        } else {
          break;
        }
      } catch (Exception e) {
        System.out.println("Please enter a valid integer!");
      }
    }
    Company company = companies.get(index - 1);
    return company;
  }

  /**
   * This is a helper function for sendEmail, checks for the type of customer this email is being
   * sent to.
   *
   * @return the Customer type as a integer (index)
   */
  private int getCustomerType() {
    Scanner scanner = new Scanner(System.in, "UTF-8");
    System.out.println("Customer types on file: ");
    for (int i = 1; i <= TYPES.length; i += 1) {
      System.out.println(i + ". " + TYPES[i - 1]);
    }
    int index;
    while (true) {
      System.out.println("Enter in the integer with your corresponding customer type: ");
      try {
        index = Integer.parseInt(scanner.nextLine()) - 1;
        if (index < 0 || index > TYPES.length) {
          System.out.println("Invalid index! Try again...");
          continue;
        } else {
          break;
        }
      } catch (Exception e) {
        System.out.println("Please enter a valid integer!");
      }
    }
    return index;
  }

  /**
   * This actually runs the central email generation system.
   */
  public void runSystem() {
    System.out.println("Starting email generation system...");
    Company company;
    Email email;
    boolean active = true;
    while (active) {
      company = getCompany();
      if (company == null) {
        System.out.println("Exiting...");
        return;
      }
      int customerType = getCustomerType();
      email = company.sendEmail(customerType);
      while (email == null) {
        System.out.println("Email type null! Try again...");
        customerType = getCustomerType();
        email = company.sendEmail(customerType);
      }
      System.out.println("The email for " + company.getName() + "'s "
          + TYPES[customerType] + " customers is:\n" + email.toString());
      Scanner scanner = new Scanner(System.in, "UTF-8");
      System.out.println("Enter 0 to quit (anything else will continue the system)...");
      try {
        int index = Integer.parseInt(scanner.nextLine());
        if (index == 0) {
          active = false;
        }
      } catch (Exception e) {
        continue;
      }
    }
  }
}
