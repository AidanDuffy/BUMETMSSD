package edu.bu.met.cs665;

import edu.bu.met.cs665.customerfactory.Business;
import edu.bu.met.cs665.customerfactory.Customer;
import edu.bu.met.cs665.customerfactory.Frequent;
import edu.bu.met.cs665.customerfactory.Newbie;
import edu.bu.met.cs665.customerfactory.Returning;
import edu.bu.met.cs665.customerfactory.Vip;

public class Company {

  private final String name;

  public Company(String name) {
    this.name = name;
  }

  /**
   * This simply returns the Company object's name.
   *
   * @return the name of the company.
   */
  public String getName() {
    return name;
  }

  /**
   * This returns the email object given the customer type.
   *
   * @param type of customer.
   * @return the email object.
   */
  public Email sendEmail(int type) {
    Customer customer = null;
    switch (type) {
      case 0:
        customer = new Business();
        break;
      case 1:
        customer = new Frequent();
        break;
      case 2:
        customer = new Newbie();
        break;
      case 3:
        customer = new Returning();
        break;
      case 4:
        customer = new Vip();
        break;
      default:
        System.out.println("Invalid type!");
        break;
    }
    if (customer == null) {
      return null;
    } else {
      return customer.getEmail();
    }
  }
}
