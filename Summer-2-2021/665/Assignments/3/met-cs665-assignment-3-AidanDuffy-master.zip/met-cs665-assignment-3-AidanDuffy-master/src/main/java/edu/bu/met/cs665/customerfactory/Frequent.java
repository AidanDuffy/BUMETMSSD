package edu.bu.met.cs665.customerfactory;

public class Frequent extends Customer {
  @Override
  String getBody() {
    return "Here is the Frequent-specific information.";
  }

  @Override
  String getFooter() {
    return "Thank you for continuing to be a valued customer!";
  }

  @Override
  String getHeader() {
    return "Hey! Frequent customers!";
  }
}
