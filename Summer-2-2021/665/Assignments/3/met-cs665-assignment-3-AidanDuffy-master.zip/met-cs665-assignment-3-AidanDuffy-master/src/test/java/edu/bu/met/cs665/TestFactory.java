package edu.bu.met.cs665;


import edu.bu.met.cs665.customerfactory.Business;
import edu.bu.met.cs665.customerfactory.Customer;
import edu.bu.met.cs665.customerfactory.Newbie;
import edu.bu.met.cs665.customerfactory.Vip;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class TestFactory {

  @Test
  public void testCustomerNewbie() {
    Customer customer = new Newbie();
    String test = "Welcome to our company!\nHere is the Newbie-specific" +
        " information.\nThe text for all customers...\nAgain, welcome to our company!";
    assertEquals(customer.getEmail().toString(), test);
  }

  @Test
  public void testCustomerVIP() {
    Customer customer = new Vip();
    String test = "Hello VIPs!\nHere is the VIP-specific information." +
        "\nThe text for all customers...\nKeep being a VIP!";
    assertEquals(customer.getEmail().toString(), test);
  }

  @Test
  public void testCustomerBusinessEncrypted() {
    Customer customer = new Business();
    String test = "Email encrypted.";
    assertEquals(customer.getEmail().toString(), test);
  }
}

