package edu.bu.met.cs665;

import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class TestSystem {

  @Test
  public void testEmail() {
    Company company = new Company("Apple");
    Email email = company.sendEmail(4);
    String test = "Hello VIPs!\nHere is the VIP-specific information." +
        "\nThe text for all customers...\nKeep being a VIP!";
    assertEquals(email.toString(), test);
  }

  @Test
  public void testSystemSingleton() {
    EmailGenerationSystem system1 = EmailGenerationSystem.getSystemSingleton();
    EmailGenerationSystem system2 = EmailGenerationSystem.getSystemSingleton();
    assertEquals(system1, system2);
    EmailGenerationSystem system3 = EmailGenerationSystem.getSystemSingleton();
    assertEquals(system1, system3);
  }
}
