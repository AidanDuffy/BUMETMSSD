# Project Template

This is a Java Maven Project Template


# How to compile the project

We use Apache Maven to compile and run this project. 

You need to install Apache Maven (https://maven.apache.org/)  on your system. 

Type on the command line: 

```bash
mvn clean compile
```

# How to create a binary runnable package 


```bash
mvn clean compile assembly:single
```


# How to run

```bash
mvn -q clean compile exec:java -Dexec.executable="edu.bu.met.cs665.Main" -Dlog4j.configuration="file:log4j.properties"
```

We recommand the above command for running the Main Java executable. 




# Run all the unit test classes.


```bash
mvn clean compile test checkstyle:check  spotbugs:check
```

# Using Spotbugs to find bugs in your project 

To see bug detail using the Findbugs GUI, use the following command "mvn findbugs:gui"

Or you can create a XML report by using  


```bash
mvn spotbugs:gui 
```

or 


```bash
mvn spotbugs:spotbugs
```


```bash
mvn spotbugs:check 
```

check goal runs analysis like spotbugs goal, and make the build failed if it found any bugs. 


For more info see 
https://spotbugs.readthedocs.io/en/latest/maven.html


SpotBugs https://spotbugs.github.io/ is the spiritual successor of FindBugs.


# Run Checkstyle 

CheckStyle code styling configuration files are in config/ directory. Maven checkstyle plugin is set to use google code style. 
You can change it to other styles like sun checkstyle. 

To analyze this example using CheckStyle run 

```bash
mvn checkstyle:check
```

This will generate a report in XML format


```bash
target/checkstyle-checker.xml
target/checkstyle-result.xml
```

and the following command will generate a report in HTML format that you can open it using a Web browser. 

```bash
mvn checkstyle:checkstyle
```

```bash
target/site/checkstyle.html
```



# Description

### Flexibility
In terms of flexibility, it is my goal to ensure that this program is as flexible as possible. Therefore, the program will
utilize a factory design pattern. The factory will be for the customers. All of the common code among all of the customers
will be placed in a separate Customers abstract class, and the code specific to the individual types of customers will be placed
in subclasses that represent these types (ie Newbie.java or Business.java). New customer types can easily be added in this way.

###Simplicity and Understandability
I wanted to ensure that the code was modular, was properly marked, well named, and commented so
that it was not cluttered, easy for developers to read, and simple enough to understand. All of the classes will be generalized
enough so that new objects can easily be created. All of the code, as mentioned above, will be placed in either the common
interface or the specialized subclasses so errors can easily be found.

###Duplication Avoidance
Given that all of the major objects will have entirely separate classes, and they will have little to no overlap, then
there will be little to no opportunity for duplications.

###Design Patterns
I utilized the factory design pattern as that made the most logical sense. When a company creates a new message request,
it will sendEmail(), learn the context of the message by entering the factory and calling getEmail() on all of the subclasses
in the factory, and populate the contents of an Email object. This will all be run by the EmailGenerationSystem. Additionally,
for the system, I used a singleton so that there can only be one instance to limit confusion and duplication.

###General Overview
Currently, the program operates from a simple factory and singleton design. A set of companies exist as well as a subset of their
customers, each of various types. The EmaiLGenerationSystem runs the setup, creates a company, who sends messages based 
on their client types. I added a rudimentary (boolean based, no cryptography) encryption option for business emails.

# Running the Program

Simply run on the Main.java in the edu.bu.met.cs665 package.


