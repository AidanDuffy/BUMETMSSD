package edu.bu.met.cs665;

import static org.junit.Assert.assertEquals;

import edu.bu.met.cs665.factory.CustomerEmail;
import edu.bu.met.cs665.factory.Rejected;
import edu.bu.met.cs665.factory.Verified;
import org.junit.Test;

// Write some Unit tests for your program like the following.

public class TestFactory {

  public TestFactory() {
  }

  @Test
  public void testVerified() {
    CustomerEmail customer = new Verified();
    String test = "Welcome back!\nHere is the Verified-specific information." +
            "\nThe text for all customers...\nWe hope we will be seeing you again!";
    assertEquals(customer.getEmail().toString(), test);
  }


  @Test
  public void testRejected() {
    CustomerEmail customer = new Rejected();
    String test = "Invalid login!\nYou failed to provide an exisiting account's information!" +
            "\nThe text for all customers...\nPlease create account!";
    assertEquals(customer.getEmail().toString(), test);
  }


}