package edu.bu.met.cs665;

import static org.junit.Assert.assertEquals;

import edu.bu.met.cs665.datamgmt.CustomerDataAdapter;
import org.junit.Test;

// Write some Unit tests for your program like the following.

public class TestDataMgmt {

    public TestDataMgmt() {
    }

    @Test
    public void testSingleton() {
        Company c = Company.getCompanySingleton();
        Company c1 = Company.getCompanySingleton();
        assertEquals(c,c1);
        Company c2 = Company.getCompanySingleton();
        assertEquals(c2,c);
        assertEquals(c1,c2);
    }


    @Test
    public void testGetCustomer() {
        Company c = Company.getCompanySingleton();
        String email = "a@a.com";
        String number  = "9085551234";
        Customer customer = new Customer(email,number);
        c.addCustomer(customer);
        CustomerDataAdapter adapter = c.getAdapter();
        Customer customer1 = adapter.getCustomer(email,number);
        assertEquals(customer1,customer);
    }


}