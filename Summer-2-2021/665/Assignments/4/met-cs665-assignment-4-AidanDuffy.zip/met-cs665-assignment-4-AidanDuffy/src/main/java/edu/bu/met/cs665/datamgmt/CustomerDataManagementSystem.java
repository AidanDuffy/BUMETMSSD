package edu.bu.met.cs665.datamgmt;

import edu.bu.met.cs665.Customer;

public interface CustomerDataManagementSystem {

  /**
   * This redirects the request to get the Customer to the old API and adds the phone number to the
   * company's customer info database.
   * @param email is the customer's email
   * @param phoneNumber is the customer's number
   * @return the customer object, null if they are not in the database.
   */
  Customer getCustomer(String email, String phoneNumber);
}
