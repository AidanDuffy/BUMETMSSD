package edu.bu.met.cs665.factory;

public class Rejected extends CustomerEmail {
  @Override
  String getBody() {
    return "You failed to provide an exisiting account's information!";
  }

  @Override
  String getFooter() {
    return "Please create account!";
  }

  @Override
  String getHeader() {
    return "Invalid login!";
  }
}
