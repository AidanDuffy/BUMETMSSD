package edu.bu.met.cs665.datamgmt;

import edu.bu.met.cs665.Customer;
import java.util.ArrayList;

public class CustomerDataSystem implements CustomerDataOld {

  private ArrayList<Customer> customers;

  public CustomerDataSystem() {
    customers = new ArrayList<>();
  }

  @Override
  public void addCustomer(Customer customer) {
    this.customers.add(customer);
  }

  @Override
  public Customer getCustomer(String email) {
    if (verifyCustomerEmail(email)) {
      for (Customer c: customers) {
        if (c.checkCustomerEmail(email)) {
          return c;
        }
      }
    } else {
      System.out.println("No user with that email found!");
    }
    return null;
  }

  /**
   * Verifies if the given Customer email is in the database.
   * @param email to be verified.
   * @return true iff the email is in the company's database.
   */
  public boolean verifyCustomerEmail(String email) {
    for (Customer c: customers) {
      if (c.checkCustomerEmail(email)) {
        return true;
      }
    }
    return false;
  }
}
