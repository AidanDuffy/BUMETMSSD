package edu.bu.met.cs665.datamgmt;

import edu.bu.met.cs665.Customer;
import java.util.ArrayList;

public interface CustomerDataOld {

  /**
   * This adds a customer to the list of customers in the database.
   * @param customer to be added,
   */
  void addCustomer(Customer customer);

  /**
   * This checks the company database for the customer email and returns it if it exists.
   * @param email the customer's email
   * @return the customer object
   */
  Customer getCustomer(String email);
}
