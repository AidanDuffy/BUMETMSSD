package edu.bu.met.cs665.datamgmt;

import edu.bu.met.cs665.Customer;

public class CustomerDataAdapter implements CustomerDataManagementSystem {

  CustomerDataSystem system;

  public CustomerDataAdapter() {
    this.system = new CustomerDataSystem();
  }

  /**
   * Adds a customer to the system's database.
   * @param customer to be added.
   */
  public void addCustomer(Customer customer) {
    this.system.addCustomer(customer);
  }

  @Override
  public Customer getCustomer(String email, String phoneNumber) {
    Customer customer = this.system.getCustomer(email);
    if (customer == null) {
      return null;
    }
    customer.addNumber(phoneNumber);
    return customer;
  }
}
