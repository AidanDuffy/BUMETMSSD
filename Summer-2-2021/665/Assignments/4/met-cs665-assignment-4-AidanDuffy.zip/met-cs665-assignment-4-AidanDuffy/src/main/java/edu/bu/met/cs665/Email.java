package edu.bu.met.cs665;

public class Email {
  private final String body;
  private final String footer;
  private final String header;


  /**
   * Standard Email object constructor.
   * @param body of the email.
   * @param footer of the email.
   * @param header of the email.
   */
  public Email(String body, String footer, String header) {
    this.body = body;
    this.footer = footer;
    this.header = header;
  }

  @Override
  public String toString() {
    return header + "\n" + body + "\n" + footer;
  }
}

