package edu.bu.met.cs665;

public class Customer {

  private String email;
  private String phoneNumber;

  public Customer(String email, String phoneNumber) {
    this.email = email;
    this.phoneNumber = phoneNumber;
  }

  /**
   * This is the constructor w/o their phone number info.
   * @param email is the customer's email.
   */
  public Customer(String email) {
    this.email = email;
  }

  /**
   * This adds a customer's phone number to their Customer profile.
   * @param phoneNumber is the customer's number.
   */
  public void addNumber(String phoneNumber) {
    this.phoneNumber = phoneNumber;
  }

  /**
   * Checks if the emails of the customers match.
   * @param email the email being checked.
   * @return true iff the emails match.
   */
  public boolean checkCustomerEmail(String email) {
    return this.email.equals(email);
  }

  /**
   * This checks if the provided customer exists.
   * @param c is the given customer
   * @return true iff the customers' info matches.
   */
  public boolean checkCustomerInfo(Customer c) {
    if (this.phoneNumber == null) {
      return this.checkCustomerEmail(c.email);
    } else {
      return this.checkCustomerEmail(c.email) && this.phoneNumber.equals(c.phoneNumber);
    }
  }

}
