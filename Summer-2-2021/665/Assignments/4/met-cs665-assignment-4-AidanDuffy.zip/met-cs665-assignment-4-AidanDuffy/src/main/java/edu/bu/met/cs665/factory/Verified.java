package edu.bu.met.cs665.factory;

public class Verified extends CustomerEmail {
  @Override
  String getBody() {
    return "Here is the Verified-specific information.";
  }

  @Override
  String getFooter() {
    return "We hope we will be seeing you again!";
  }

  @Override
  String getHeader() {
    return "Welcome back!";
  }
}
