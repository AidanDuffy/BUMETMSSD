package edu.bu.met.cs665;

import edu.bu.met.cs665.datamgmt.CustomerDataAdapter;
import edu.bu.met.cs665.factory.CustomerEmail;
import edu.bu.met.cs665.factory.Rejected;
import edu.bu.met.cs665.factory.Verified;
import java.util.ArrayList;
import java.util.Scanner;

public class Company {

  private CustomerDataAdapter adapter;
  private static final Company singleton = new Company();

  private Company() {
    this.adapter = new CustomerDataAdapter();
  }

  /**
   * Adds a customer object to the customer database.
   * @param customer object.
   */
  public void addCustomer(Customer customer) {
    this.adapter.addCustomer(customer);
  }

  public CustomerDataAdapter getAdapter() {
    return adapter;
  }

  /**
   * Gets the singleton of the company object.
   * @return company singleton
   */
  public static Company getCompanySingleton() {
    return singleton;
  }

  /**
   * Runs the system for email generation.
   */
  public void runSysten() {
    System.out.println("Starting customer verification process and email generation... ");
    Scanner scanner = new Scanner(System.in, "UTF-8");
    while (true) {
      System.out.println("Please input customer email(enter 0 to exit): ");
      String custEmail = scanner.nextLine();
      if (custEmail.equals("0")) {
        break;
      }
      System.out.println("Please input customer phone number: ");
      String custNumber = scanner.nextLine();
      Customer customer = this.adapter.getCustomer(custEmail, custNumber);
      boolean acceptedCustomer;
      if (customer == null) {
        acceptedCustomer = false;
      } else {
        acceptedCustomer = true;
      }
      Email email = sendEmail(acceptedCustomer);
      System.out.printf("The generated email for the customer with email " + custEmail + " and"
              + " phone number " + custNumber + " is:\n");
      System.out.println(email.toString());
      System.out.println("Proceeding to next customer...");
    }
  }

  /**
   * Creates an email for this type of login.
   * @param accepted whether or not the login was accepted.
   * @return the new CustomerEmail
   */
  public Email sendEmail(boolean accepted) {
    CustomerEmail customerEmail;
    if (accepted) {
      customerEmail = new Verified();
    } else {
      customerEmail = new Rejected();
    }
    return customerEmail.getEmail();
  }

}
