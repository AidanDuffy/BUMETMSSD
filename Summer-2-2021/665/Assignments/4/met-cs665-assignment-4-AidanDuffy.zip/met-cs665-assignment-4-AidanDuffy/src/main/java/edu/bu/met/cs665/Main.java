package edu.bu.met.cs665;

import java.util.ArrayList;
import org.apache.log4j.Logger;
// import org.apache.log4j.PropertyConfigurator;

public class Main {

  private static Logger logger = Logger.getLogger(Main.class);


  /**
   * A main method to run examples.
   *
   * @param args not used
   */
  public static void main(String[] args) {
    ArrayList<Customer> customers = generateMockCustomers();
    Company amazon = Company.getCompanySingleton();
    for (Customer c: customers) {
      amazon.addCustomer(c);
    }
    amazon.runSysten();
  }

  private static ArrayList<Customer> generateMockCustomers() {
    String template = "sample";
    String email = "@gmail.com";
    ArrayList<Customer> customers = new ArrayList<>();
    for (int i = 0; i < 10; i += 1) {
      Customer c = new Customer(template + Integer.toString(i) + email);
      customers.add(c);
    }
    return customers;
  }

}
