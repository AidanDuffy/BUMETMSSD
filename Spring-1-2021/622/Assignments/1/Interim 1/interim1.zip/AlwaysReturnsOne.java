public class AlwaysReturnsOne {

    public static void main(String[] args) {
        System.out.println();
    }

    public static int one() {
        int one = 1;
        return one;
    }
}
