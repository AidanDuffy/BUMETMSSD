package fragments;

// A portion of a text passage, such as a sentence

public abstract class Fragment {
// Pedagogical: (1) Attributes (2) Constructors (3) Methods, 
// alphabetically ordered within each.
	
	protected String fragmentText = "text not determined yet";
	
	public Fragment() {
	}
	
	public Fragment(String someText) {
		fragmentText = someText;
	}
	
	// Pedagogical: (expressive) names alone are often sufficient for abstract methods.
	public abstract void display();
	public abstract String getText(); // Pedagogical: "get..()" and "set...()" standard
	public abstract String getType();
	public abstract void setText(String someText);
}
