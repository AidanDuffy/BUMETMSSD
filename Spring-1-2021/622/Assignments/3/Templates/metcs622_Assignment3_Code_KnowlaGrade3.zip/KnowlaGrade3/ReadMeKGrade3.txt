 REQUIREMENTS
 
 Grades a student answer to a scrambled set of text fragments.
 The problem is given as a set sentences, known to the grading system by number, 
 such as 3 4 7 11 2 5 1.
 The answer is of the form 1 2 3 4 (i.e., does not necessarily include all fragments).
 The system uses rubric sets to evaluate an answer. For example, the "order" rubrics 
 are associated with the class OrderRubrics--where the specifications of an associated 
 file are specified.
 
 NEEDED INPUT FILES
 consecutive_rubrics.txt, whose records are exemplified by:
 1 2 7 You are correct that #1 and #2 are consecutive (7 points).
 order_rubrics.txt, whose records are exemplified by:
 4 6 8 You are correct that #4 occurs before #6 (8 points).
 
 
 TO EXECUTE
 
 MainKGrade3.main()
